/* =====================================================================
   PROGRESSION EN LIGNE — fonction serveur (Netlify Functions v2)
   ---------------------------------------------------------------------
   Un joueur choisit un code personnel (4 a 12 lettres/chiffres) et envoie
   un instantane de sa progression (scores par intervention, XP, historique,
   notes de fiches bilan). Il le recupere depuis n'importe quel telephone.
   Stockage : Netlify Blobs, cle joueurs/CODE. Zero dependance : meme client
   Blobs inline que la fonction equipage ; memoire en repli hors Netlify.
   Contrat identique a la version Render (server.js) :
     { a:'sauver', code, data }  -> { ok, code, maj }
     { a:'charger', code }       -> { ok, code, maj, data }
   ===================================================================== */

const memoire = new Map();
const CODE_OK = /^[A-Z0-9]{4,12}$/;

function ctxBlobs(){
  try{
    const b64 = process.env.NETLIFY_BLOBS_CONTEXT;
    if(!b64) return null;
    const c = JSON.parse(Buffer.from(b64, 'base64').toString('utf8'));
    if(!c.edgeURL || !c.token || !c.siteID) return null;
    return c;
  }catch(e){ return null; }
}
async function lire(code){
  const c = ctxBlobs();
  if(!c) return memoire.get(code) || null;
  const r = await fetch(c.edgeURL + '/' + c.siteID + '/joueurs/' + code,
    { headers:{ authorization:'Bearer ' + c.token } });
  if(r.status === 404) return null;
  if(!r.ok) throw new Error('blobs GET ' + r.status);
  return await r.json();
}
async function ecrire(code, doc){
  const c = ctxBlobs();
  if(!c){ memoire.set(code, doc); return; }
  const r = await fetch(c.edgeURL + '/' + c.siteID + '/joueurs/' + code,
    { method:'PUT', headers:{ authorization:'Bearer ' + c.token, 'content-type':'application/json' },
      body: JSON.stringify(doc) });
  if(!r.ok) throw new Error('blobs PUT ' + r.status);
}

export async function progression(q){
  const code = String(q.code||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,12);
  if(!CODE_OK.test(code)) return { ok:false, err:'code invalide (4 a 12 lettres ou chiffres)' };
  if(q.a==='charger'){
    const d = await lire(code);
    if(!d) return { ok:false, err:'aucune sauvegarde pour ce code', code };
    return { ok:true, code, maj:d.maj, data:d.data };
  }
  if(q.a==='sauver'){
    if(!q.data || typeof q.data!=='object') return { ok:false, err:'donnees absentes' };
    const brut = JSON.stringify(q.data);
    if(brut.length > 400000) return { ok:false, err:'sauvegarde trop volumineuse' };
    const doc = { v:1, code, maj:new Date().toISOString(), data:q.data };
    await ecrire(code, doc);
    return { ok:true, code, maj:doc.maj };
  }
  return { ok:false, err:'action inconnue' };
}

export default async (req) => {
  if(req.method==='OPTIONS')
    return new Response(null, { status:204, headers:{ 'access-control-allow-origin':'*',
      'access-control-allow-methods':'POST', 'access-control-allow-headers':'content-type' } });
  if(req.method!=='POST')
    return new Response(JSON.stringify({ok:false,err:'POST uniquement'}), { status:405,
      headers:{ 'content-type':'application/json' } });
  let q={};
  try{ q=await req.json(); }catch(e){}
  let rep;
  try{ rep=await progression(q); }
  catch(e){ rep={ ok:false, err:'serveur : '+String(e&&e.message||e).slice(0,120) }; }
  return new Response(JSON.stringify(rep), { headers:{
    'content-type':'application/json', 'cache-control':'no-store', 'access-control-allow-origin':'*' } });
};

export const config = { path:'/api/progression' };
