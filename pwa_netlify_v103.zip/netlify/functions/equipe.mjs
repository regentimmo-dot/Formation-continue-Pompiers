/* =====================================================================
   ÉQUIPAGE EN LIGNE — fonction serveur (Netlify Functions v2)
   ---------------------------------------------------------------------
   Une « équipe » = un document JSON stocké dans Netlify Blobs, identifié
   par un code à 4 lettres. Trois rôles : chef (chef d'agrès), cond
   (conducteur), eq (équipier). Les téléphones interrogent l'état toutes
   les ~2,5 s : le jeu est au tour par tour, pas besoin de websocket.

   Zéro dépendance : le client Blobs est écrit ici même (l'environnement
   d'exécution fournit l'URL et le jeton dans NETLIFY_BLOBS_CONTEXT).
   Hors Netlify (tests locaux), un stockage mémoire prend le relais.
   ===================================================================== */

const memoire = new Map();          /* repli local : tests et netlify dev */

function ctxBlobs(){
  try{
    const b64 = process.env.NETLIFY_BLOBS_CONTEXT;
    if(!b64) return null;
    const c = JSON.parse(Buffer.from(b64, 'base64').toString('utf8'));
    if(!c.edgeURL || !c.token || !c.siteID) return null;
    return c;
  }catch(e){ return null; }
}
async function lire(code){
  const c = ctxBlobs();
  if(!c) return memoire.get(code) || null;
  const r = await fetch(c.edgeURL + '/' + c.siteID + '/equipes/' + code,
    { headers:{ authorization:'Bearer ' + c.token } });
  if(r.status === 404) return null;
  if(!r.ok) throw new Error('blobs GET ' + r.status);
  return await r.json();
}
async function ecrire(code, doc){
  const c = ctxBlobs();
  if(!c){ memoire.set(code, doc); return; }
  const r = await fetch(c.edgeURL + '/' + c.siteID + '/equipes/' + code,
    { method:'PUT', headers:{ authorization:'Bearer ' + c.token, 'content-type':'application/json' },
      body: JSON.stringify(doc) });
  if(!r.ok) throw new Error('blobs PUT ' + r.status);
}

const ROLES = ['chef','cond','eq'];
const AGE_MAX = 1000*60*60*6;       /* une équipe vit 6 h */
const PING_ACTIF = 1000*45;         /* membre considéré présent si vu < 45 s */

function codeNeuf(){
  /* 4 lettres sans ambiguïté (pas de O/I) */
  const A='ABCDEFGHJKLMNPQRSTUVWXYZ';
  let s=''; for(let i=0;i<4;i++) s+=A[Math.floor(Math.random()*A.length)];
  return s;
}
function nettoie(doc){
  const t=Date.now();
  for(const r of ROLES){
    if(doc.membres[r] && t-doc.membres[r].ping > PING_ACTIF) doc.membres[r].present=false;
  }
  return doc;
}
function presents(doc){ return ROLES.filter(r=>doc.membres[r] && doc.membres[r].present); }

/* Toute la logique est ici, pure, testable sans réseau. */
export async function traite(q){
  const a = String(q.a||'');
  const t = Date.now();

  /* sonde de joignabilite : permet au client d'afficher clairement si la
     fonction serveur est bien deployee (probleme n°1 des mises en ligne) */
  if(a==='ping') return { ok:true, pong:true, blobs: !!ctxBlobs() };

  if(a==='creer'){
    let code, essais=0;
    do{ code=codeNeuf(); essais++; }while(await lire(code) && essais<20);
    const doc={ v:1, code, cree:t, phase:'salle', missions:0,
      membres:{ chef:{ nom:String(q.nom||'Chef').slice(0,16), ping:t, present:true, fini:false, score:null } },
      mission:null, nav:null };
    await ecrire(code, doc);
    return { ok:true, code, role:'chef', doc };
  }

  const code=String(q.code||'').toUpperCase().replace(/[^A-Z]/g,'').slice(0,4);
  if(code.length!==4) return { ok:false, err:'code invalide' };
  let doc=await lire(code);
  if(!doc || t-doc.cree>AGE_MAX) return { ok:false, err:'equipe introuvable ou expiree' };
  nettoie(doc);

  if(a==='rejoindre'){
    const role=String(q.role||'');
    if(ROLES.indexOf(role)<0) return { ok:false, err:'role inconnu' };
    if(doc.membres[role] && doc.membres[role].present) return { ok:false, err:'role deja pris', doc };
    doc.membres[role]={ nom:String(q.nom||role).slice(0,16), ping:t, present:true, fini:false, score:null };
    await ecrire(code, doc);
    return { ok:true, code, role, doc };
  }

  const role=String(q.role||'');
  if(doc.membres[role]) { doc.membres[role].ping=t; doc.membres[role].present=true; }

  if(a==='etat'){ await ecrire(code, doc); return { ok:true, doc }; }

  if(a==='quitter'){
    if(doc.membres[role]) doc.membres[role].present=false;
    await ecrire(code, doc);
    return { ok:true, doc };
  }

  if(a==='lancer'){
    if(doc.phase!=='salle' && doc.phase!=='bilan') return { ok:false, err:'deja en cours', doc };
    for(const r of ROLES) if(doc.membres[r]){ doc.membres[r].fini=false; doc.membres[r].score=null; }
    doc.mission=null; doc.nav=null;
    /* domaine choisi par l'equipe : mix (defaut), ssuap ou fire */
    doc.pref = (['mix','ssuap','fire'].indexOf(q.pref)>=0)? q.pref : (doc.pref||'mix');
    doc.phase='prep';                       /* un téléphone va tirer la mission */
    await ecrire(code, doc);
    return { ok:true, doc };
  }

  if(a==='mission'){
    if(doc.phase!=='prep') return { ok:true, doc };   /* déjà fait par un autre */
    const m=q.mission||{};
    doc.mission={ type:(m.type==='fire'?'fire':'ssuap'), idx:Math.max(0,m.idx|0),
                  cible:m.cible|0, lieu:String(m.lieu||'').slice(0,80), titre:String(m.titre||'').slice(0,120) };
    doc.phase=(doc.membres.cond && doc.membres.cond.present)? 'nav' : 'inter';
    await ecrire(code, doc);
    return { ok:true, doc };
  }

  if(a==='navpos'){
    if(doc.phase==='nav'){ const nv=q.nav||{};
      doc.nav={ rue:String(nv.rue||'').slice(0,60), reste:String(nv.reste||'').slice(0,16),
                t:String(nv.t||'').slice(0,8) }; await ecrire(code, doc); }
    return { ok:true, doc };
  }

  if(a==='arrive'){
    if(doc.phase==='nav'){ doc.phase='inter'; await ecrire(code, doc); }
    return { ok:true, doc };
  }

  if(a==='fini'){
    if(doc.membres[role]){ doc.membres[role].fini=true;
      if(q.score!==undefined && q.score!==null) doc.membres[role].score=Math.max(0,Math.min(100,q.score|0)); }
    if(doc.phase==='inter' && presents(doc).every(r=>doc.membres[r].fini)){
      doc.phase='bilan'; doc.missions++;
    }
    await ecrire(code, doc);
    return { ok:true, doc };
  }

  return { ok:false, err:'action inconnue' };
}

export default async (req) => {
  if(req.method==='OPTIONS')
    return new Response(null, { status:204, headers:{ 'access-control-allow-origin':'*',
      'access-control-allow-methods':'POST', 'access-control-allow-headers':'content-type' } });
  if(req.method!=='POST')
    return new Response(JSON.stringify({ok:false,err:'POST uniquement'}), { status:405,
      headers:{ 'content-type':'application/json' } });
  let q={};
  try{ q=await req.json(); }catch(e){}
  let rep;
  try{ rep=await traite(q); }
  catch(e){ rep={ ok:false, err:'serveur : '+String(e&&e.message||e).slice(0,120) }; }
  return new Response(JSON.stringify(rep), { headers:{
    'content-type':'application/json',
    'cache-control':'no-store',
    'access-control-allow-origin':'*' } });
};

export const config = { path:'/api/equipe' };
