# Formation continue Pompiers — version PWA (Netlify)

Déposez le CONTENU de ce dossier à la racine du site Netlify (glisser-déposer
du dossier sur app.netlify.com, ou dépôt Git). Les fonctions `/api/equipe`
et `/api/progression` vivent dans `netlify/functions` et utilisent Netlify
Blobs : mode équipage et sauvegarde de progression fonctionnent sur l'offre
gratuite.

Rappel : un déploiement en production coûte 15 crédits sur les 300 du mois
(plan Free). Mettez en ligne une version quand elle est prête, pas à chaque
essai. Le cache du service worker est `ca-vsav-v103` : les téléphones déjà
installés récupèrent la nouvelle version au prochain lancement.
