/* =====================================================================
   FORMATION CONTINUE POMPIERS — serveur Render
   ---------------------------------------------------------------------
   Un seul processus Node, sans dependance externe :
     - sert l'application (index.html, sw.js, manifest, icones) ;
     - expose /api/equipe   : le mode equipage a trois telephones ;
     - expose /api/progression : sauvegarde et restitution de la
       progression d'un joueur, par code personnel.
   Persistance : fichiers JSON sous DATA_DIR (disque Render persistant si
   monte, /tmp sinon). Rien de sensible n'est stocke : un prenom, des
   scores, des codes d'equipe.
   ===================================================================== */
'use strict';
const http = require('http');
const fs   = require('fs');
const path = require('path');
const { traite, injecteStockage } = require('./equipe.js');

const PORT     = process.env.PORT || 10000;
const RACINE   = path.join(__dirname, 'public');
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');

try { fs.mkdirSync(path.join(DATA_DIR, 'equipes'), { recursive: true }); } catch (e) {}
try { fs.mkdirSync(path.join(DATA_DIR, 'joueurs'), { recursive: true }); } catch (e) {}

/* ---------- stockage fichier pour le module equipage ---------- */
const fEquipe = (code) => path.join(DATA_DIR, 'equipes', code.replace(/[^A-Z]/g, '') + '.json');
injecteStockage({
  async lire(code) {
    try { return JSON.parse(fs.readFileSync(fEquipe(code), 'utf8')); }
    catch (e) { return null; }
  },
  async ecrire(code, doc) {
    fs.writeFileSync(fEquipe(code), JSON.stringify(doc));
  },
});

/* ---------- progression : un fichier par code personnel ---------- */
const CODE_OK  = /^[A-Z0-9]{4,12}$/;
const fJoueur  = (code) => path.join(DATA_DIR, 'joueurs', code + '.json');

function progression(q) {
  const code = String(q.code || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12);
  if (!CODE_OK.test(code)) return { ok: false, err: 'code invalide (4 a 12 lettres ou chiffres)' };

  if (q.a === 'charger') {
    try {
      const d = JSON.parse(fs.readFileSync(fJoueur(code), 'utf8'));
      return { ok: true, code, maj: d.maj, data: d.data };
    } catch (e) { return { ok: false, err: 'aucune sauvegarde pour ce code', code }; }
  }
  if (q.a === 'sauver') {
    if (!q.data || typeof q.data !== 'object') return { ok: false, err: 'donnees absentes' };
    const brut = JSON.stringify(q.data);
    if (brut.length > 400000) return { ok: false, err: 'sauvegarde trop volumineuse' };
    const doc = { v: 1, code, maj: new Date().toISOString(), data: q.data };
    fs.writeFileSync(fJoueur(code), JSON.stringify(doc));
    return { ok: true, code, maj: doc.maj };
  }
  return { ok: false, err: 'action inconnue' };
}

/* ---------- utilitaires HTTP ---------- */
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
};

function corpsJSON(req) {
  return new Promise((res) => {
    let b = '';
    req.on('data', (c) => { b += c; if (b.length > 500000) req.destroy(); });
    req.on('end', () => { try { res(JSON.parse(b || '{}')); } catch (e) { res({}); } });
  });
}
function repJSON(rq, obj, code) {
  const s = JSON.stringify(obj);
  rq.writeHead(code || 200, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'access-control-allow-origin': '*',
  });
  rq.end(s);
}

const serveur = http.createServer(async (req, rq) => {
  const url = new URL(req.url, 'http://x');
  const chemin = decodeURIComponent(url.pathname);

  if (req.method === 'OPTIONS') {
    rq.writeHead(204, {
      'access-control-allow-origin': '*',
      'access-control-allow-methods': 'POST, GET',
      'access-control-allow-headers': 'content-type',
    });
    return rq.end();
  }

  /* --- API équipage --- */
  if (chemin === '/api/equipe') {
    if (req.method !== 'POST') return repJSON(rq, { ok: false, err: 'POST uniquement' }, 405);
    const q = await corpsJSON(req);
    try { return repJSON(rq, await traite(q)); }
    catch (e) { return repJSON(rq, { ok: false, err: 'serveur : ' + String(e && e.message || e).slice(0, 120) }, 200); }
  }

  /* --- API progression --- */
  if (chemin === '/api/progression') {
    if (req.method !== 'POST') return repJSON(rq, { ok: false, err: 'POST uniquement' }, 405);
    const q = await corpsJSON(req);
    try { return repJSON(rq, progression(q)); }
    catch (e) { return repJSON(rq, { ok: false, err: 'serveur : ' + String(e && e.message || e).slice(0, 120) }, 200); }
  }

  /* --- sonde de sante (Render) --- */
  if (chemin === '/sante') return repJSON(rq, { ok: true, up: process.uptime() });

  /* --- fichiers statiques --- */
  let rel = chemin === '/' ? '/index.html' : chemin;
  const f = path.join(RACINE, rel);
  if (!f.startsWith(RACINE) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) {
    rq.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
    return rq.end('404');
  }
  const ext = path.extname(f).toLowerCase();
  const entetes = { 'content-type': MIME[ext] || 'application/octet-stream' };
  /* le service worker et la coquille ne doivent jamais rester en cache HTTP */
  entetes['cache-control'] = (/sw\.js$|index\.html$|manifest/.test(f)) ? 'no-cache' : 'public, max-age=86400';
  rq.writeHead(200, entetes);
  fs.createReadStream(f).pipe(rq);
});

serveur.listen(PORT, () => {
  console.log('Formation continue Pompiers — en écoute sur le port ' + PORT);
  console.log('  données : ' + DATA_DIR);
});
