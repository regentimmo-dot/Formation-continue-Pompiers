/* Service worker — coquille applicative en cache-first.
   Le nom du cache PORTE la version : tout changement de contenu impose de le bumper,
   sinon les appareils deja installes conservent l'ancienne version indefiniment. */
const CACHE = 'ca-vsav-v71';
const SHELL = ['./', './index.html', './manifest.webmanifest',
               './icon-192.png', './icon-512.png', './icon-512-maskable.png', './icon-180.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;   // aucune ressource externe attendue
  if (url.pathname.startsWith('/api/')) return;      // l'API equipage ne se met jamais en cache

  // Navigation : cache d'abord (usage hors ligne en caserne), reseau en secours.
  if (req.mode === 'navigate') {
    e.respondWith(
      caches.match('./index.html').then((hit) => hit || fetch(req).catch(() => caches.match('./')))
    );
    return;
  }
  e.respondWith(
    caches.match(req).then((hit) => hit || fetch(req).then((res) => {
      const copy = res.clone();
      caches.open(CACHE).then((c) => c.put(req, copy)).catch(() => {});
      return res;
    }).catch(() => hit))
  );
});

// Permet a la page de forcer l'activation d'une nouvelle version apres confirmation.
self.addEventListener('message', (e) => { if (e.data === 'skipWaiting') self.skipWaiting(); });
