# Formation continue Pompiers — version serveur (Render)

Cette version fait tourner l'application **avec un serveur**, ce qui apporte
deux choses que la version hors-ligne ne peut pas offrir :

- le **mode équipage** à trois téléphones (chef d'agrès, conducteur, équipier) ;
- la **sauvegarde de progression** par code personnel, récupérable depuis
  n'importe quel téléphone.

## Déployer sur Render (5 minutes, offre gratuite)

1. Créez un dépôt (GitHub ou GitLab) contenant **le contenu de ce dossier**
   (`server.js`, `equipe.js`, `package.json`, `render.yaml`, `public/`).
2. Sur render.com : **New → Web Service**, choisissez ce dépôt.
   Render lit `render.yaml` et remplit tout seul :
   - Runtime **Node**, Build `echo aucune dependance`, Start `node server.js`
   - Health check `/sante`
3. **Disque** : gardez le disque `donnees` monté sur `/var/data` (1 Go).
   Sans lui, l'offre gratuite efface les sauvegardes à chaque redémarrage.
4. Déployez. L'adresse est du type `https://formation-continue-pompiers.onrender.com`.

Aucune dépendance à installer : le serveur n'utilise que Node.

## Utilisation

- **Équipage** : ouvrez l'adresse sur les trois téléphones →
  carte « 👥 Équipage » → un joueur crée l'équipe, les autres saisissent
  le code de 4 lettres et choisissent leur rôle.
- **Progression** : écran **Statistiques** → bloc « Sauvegarde en ligne » →
  choisissez un code personnel (4 à 12 caractères) → **↑ Envoyer**.
  Sur un autre téléphone, même code → **↓ Récupérer**.

## Ce qui est stocké

Sous `DATA_DIR` (par défaut `/var/data` sur Render) :

- `equipes/CODE.json` — une session d'équipe (prénoms, rôles, mission,
  scores), effacée d'elle-même au bout de 6 h ;
- `joueurs/CODE.json` — l'instantané de progression d'un joueur
  (scores par intervention, XP, historique, notes de fiches bilan).

Aucune donnée personnelle au-delà du prénom saisi par le joueur.

## Mise à jour de l'application

Remplacez `public/index.html` (et les icônes si elles changent) par la
nouvelle version, puis redéployez. Pensez à ce que le numéro de cache du
service worker (`public/sw.js`, constante `CACHE`) ait bien changé, sinon
les téléphones déjà installés garderont l'ancienne version.

## Différence avec la version Netlify

Les deux sont fournies et fonctionnent pareil côté joueur. Render tient
l'application et les deux API dans un seul processus Node avec un disque ;
Netlify sert les fichiers et exécute deux fonctions (`/api/equipe`,
`/api/progression`) adossées à Netlify Blobs. Sur l'offre gratuite de
Render, le service s'endort après inactivité : le premier chargement peut
demander une trentaine de secondes.
