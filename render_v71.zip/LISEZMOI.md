# Formation continue Pompiers — version serveur (Render)

Cette version fait tourner l'application **avec un serveur**, ce qui apporte
deux choses que la version hors-ligne ne peut pas offrir :

- le **mode équipage** à trois téléphones (chef d'agrès, conducteur, équipier) ;
- la **sauvegarde de progression** par code personnel, récupérable depuis
  n'importe quel téléphone.

---

## ⚠️ Le plus important : la STRUCTURE du dépôt

Les fichiers doivent être **à la racine du dépôt**, pas dans un sous-dossier :

```
votre-depot/
├── server.js
├── equipe.js
├── package.json
├── Dockerfile
├── render.yaml
└── public/
    ├── index.html
    ├── sw.js
    ├── manifest.webmanifest
    └── icon-*.png
```

Si vous voyez `render/server.js` dans votre dépôt, c'est qu'un dossier est
en trop : remontez le contenu d'un niveau. Render cherche `server.js` (ou
`Dockerfile`) **à la racine** ; s'il ne les trouve pas, le déploiement
s'arrête avec « exited with status 1 ».

---

## Déployer (5 minutes, offre gratuite)

1. Créez un dépôt GitHub/GitLab avec les fichiers **à la racine** (ci-dessus).
2. Sur render.com : **New → Web Service**, choisissez ce dépôt.
3. Réglages — les deux fonctionnent, prenez celui que Render vous propose :
   - **Runtime Node** (le plus léger)
     - Build Command : `echo aucune dependance`
     - Start Command : `node server.js`
   - **Runtime Docker** : rien à saisir, le `Dockerfile` fourni fait tout.
4. **Disque** : ajoutez un disque, nom `donnees`, chemin `/var/data`, 1 Go.
   Sans lui, l'offre gratuite efface les sauvegardes à chaque redémarrage.
5. Health check path : `/sante`.
6. Déployez. L'adresse ressemble à
   `https://formation-continue-pompiers.onrender.com`.

Aucune dépendance à installer : le serveur n'utilise que Node.

### Si le déploiement a déjà échoué

Le message **« failed to read dockerfile: open Dockerfile: no such file or
directory »** signifie que Render est en mode Docker sans trouver de
`Dockerfile`. Deux façons de s'en sortir :

- **le plus simple** : ce paquet contient désormais un `Dockerfile` —
  poussez-le à la racine du dépôt et relancez le déploiement (*Manual Deploy
  → Deploy latest commit*) ;
- ou basculez le service en Node : **Settings → Runtime → Node**, avec les
  commandes de build et de démarrage ci-dessus.

---

## Utilisation

- **Équipage** : ouvrez l'adresse sur les trois téléphones →
  carte « 👥 Équipage » → un joueur crée l'équipe, les autres saisissent
  le code de 4 lettres et choisissent leur rôle.
- **Progression** : écran **Statistiques** → bloc « Sauvegarde en ligne » →
  choisissez un code personnel (4 à 12 caractères) → **↑ Envoyer**.
  Sur un autre téléphone, même code → **↓ Récupérer**.

## Ce qui est stocké

Sous `DATA_DIR` (par défaut `/var/data` sur Render) :

- `equipes/CODE.json` — une session d'équipe (prénoms, rôles, mission,
  scores), effacée d'elle-même au bout de 6 h ;
- `joueurs/CODE.json` — l'instantané de progression d'un joueur
  (scores par intervention, XP, historique, notes de fiches bilan).

Aucune donnée personnelle au-delà du prénom saisi par le joueur.

## Mettre à jour l'application

Remplacez `public/index.html` (et les icônes si elles changent), poussez,
puis redéployez. Vérifiez que le numéro de cache du service worker
(`public/sw.js`, constante `CACHE`) a bien changé : sinon les téléphones
déjà installés garderont l'ancienne version.

## Différence avec la version Netlify

Les deux sont fournies et se valent côté joueur. Render tient l'application
et les deux API dans un seul processus Node avec un disque ; Netlify sert les
fichiers et exécute deux fonctions (`/api/equipe`, `/api/progression`)
adossées à Netlify Blobs. Sur l'offre gratuite de Render, le service s'endort
après inactivité : le premier chargement peut demander une trentaine de
secondes.
