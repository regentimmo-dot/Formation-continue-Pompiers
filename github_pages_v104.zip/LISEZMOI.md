# Formation continue Pompiers — GitHub Pages (v104)

Miroir statique. **Tout le contenu fonctionne** : les 152 scénarios, le
parcours 30 jours et ses 218 questions, les fiches, la recherche, la
progression enregistrée sur le téléphone. Gratuit, sans limite de
déploiements utile, 100 Go de bande passante par mois.

**Deux choses ne marchent pas ici**, parce qu'elles ont besoin d'un serveur
et que GitHub Pages n'en fournit aucun :

- la sauvegarde de progression en ligne (le code personnel) ;
- le mode équipage à plusieurs téléphones.

L'application le dit clairement au lieu de planter : « Serveur injoignable ».

C'est donc le bon filet de sécurité si Netlify est à sec en fin de mois —
pas un remplacement complet. Pour tout garder, c'est le paquet Cloudflare.

## Mise en ligne

1. Sur GitHub, crée un dépôt **public** (par exemple `pompiers`).
2. Dépose le contenu de ce dossier à la racine du dépôt — les fichiers, pas
   le dossier. Le fichier `.nojekyll` doit être du lot : sans lui, GitHub
   ignore certains fichiers.
3. Le dépôt → **Settings** → **Pages** → Source : *Deploy from a branch*,
   branche `main`, dossier `/ (root)`. Enregistre.
4. Au bout d'une minute, le site est sur
   `https://<ton-compte>.github.io/pompiers/`.

Attention : un dépôt **privé** exige un compte payant pour publier des
Pages. Le dépôt doit être public — le contenu est de la doctrine SDIS 77
diffusée en interne, à toi de voir si ça te convient. Sinon, reste sur
Cloudflare, où le site n'est pas indexé tant que tu ne le partages pas.

## Retrouver la synchro depuis ce miroir

Si tu as monté le site Cloudflare, tu peux brancher ce miroir dessus.
Ouvre `index.html`, cherche `__PROG_API` tout en haut (dans le `<head>`) et
remplis les deux lignes :

```js
window.__PROG_API = 'https://pompiers.pages.dev/api/progression';
window.__EQ_API   = 'https://pompiers.pages.dev/api/equipe';
```

Les fonctions Cloudflare acceptent les appels venus d'un autre domaine, il
n'y a rien d'autre à régler. Redépose le fichier, c'est fait.

## Mises à jour

Remplace `index.html` et `sw.js` dans le dépôt. Le cache du service worker
s'appelle `ca-vsav-v104` : sur le téléphone, ferme complètement l'onglet
Safari et rouvre le site pour qu'il bascule.
