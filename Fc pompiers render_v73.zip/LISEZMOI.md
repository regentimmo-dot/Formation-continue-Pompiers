# Formation continue Pompiers — version serveur (Render)

Cette version fait tourner l'application **avec un serveur**, ce qui apporte
deux choses que la version hors-ligne ne peut pas offrir :

- le **mode équipage** à trois téléphones (chef d'agrès, conducteur, équipier) ;
- la **sauvegarde de progression** par code personnel, récupérable depuis
  n'importe quel téléphone.

---

## ⚠️ Depuis un iPhone : ne tapez AUCUNE commande

Le clavier iOS met une majuscule et parfois un accent au premier mot de
chaque champ. `echo aucune dependance` devient `Écho aucune dependance`, et
le build s'arrête sur :

```
bash: line 1: Écho: command not found
==> Build failed
```

Ce n'est pas votre dépôt qui est en cause : c'est l'autocorrection. Deux
façons de ne rien avoir à taper du tout — prenez l'une des deux.

### Solution A — Blueprint (recommandée)

Le fichier `render.yaml` fourni contient déjà tous les réglages.

1. Poussez le dépôt (fichiers **à la racine**, voir plus bas).
2. Sur Render : **New → Blueprint**, choisissez le dépôt, **Apply**.
3. C'est tout. Aucun champ à remplir.

### Solution B — runtime Docker

Le `Dockerfile` fourni fait tout, et l'écran de création ne demande alors
**ni Build Command ni Start Command**.

1. **New → Web Service**, choisissez le dépôt.
2. **Language : Docker**.
3. Déployez.

### Si vous tenez à remplir le formulaire à la main

| Champ | Valeur exacte |
|---|---|
| **Language** | **Node** (surtout pas Rust) |
| Branch | `main` |
| **Root Directory** | *laisser vide* |
| **Build Command** | `npm install` |
| **Start Command** | `node server.js` |
| Health Check Path | `/sante` |
| Instance Type | Free |

`npm install` est le bon choix ici : le projet n'a **aucune dépendance**, la
commande se termine donc aussitôt, et c'est la valeur que Render propose
déjà par défaut — souvent sans avoir à la retaper. Si vous devez taper :
vérifiez qu'il n'y a **ni majuscule ni accent** (Réglages → Général →
Clavier → Majuscules automatiques, désactivé).

### Rappel des erreurs déjà rencontrées

| Message | Cause | Remède |
|---|---|---|
| `Écho: command not found` (status 127) | autocorrection iOS | Blueprint, Docker, ou `npm install` |
| `cargo build --release` | **Language** resté sur **Rust** | passer Language à **Node** |
| `failed to read dockerfile` (status 1) | fichiers dans un sous-dossier | tout remonter à la racine |

---

## ⚠️ Le plus important : la STRUCTURE du dépôt

Les fichiers doivent être **à la racine du dépôt**, pas dans un sous-dossier :

```
votre-depot/
├── server.js
├── equipe.js
├── package.json
├── Dockerfile
├── render.yaml
└── public/
    ├── index.html
    ├── sw.js
    ├── manifest.webmanifest
    └── icon-*.png
```

Si vous voyez `render/server.js` dans votre dépôt, c'est qu'un dossier est
en trop : remontez le contenu d'un niveau. Render cherche `server.js` (ou
`Dockerfile`) **à la racine** ; s'il ne les trouve pas, le déploiement
s'arrête avec « exited with status 1 ».

---

## Déployer (5 minutes, offre gratuite)

1. Créez un dépôt GitHub/GitLab avec les fichiers **à la racine** (ci-dessus).
2. Sur render.com : **New → Web Service**, choisissez ce dépôt.
3. Réglages — les deux fonctionnent, prenez celui que Render vous propose :
   - **Runtime Node** (le plus léger)
     - Build Command : `echo aucune dependance`
     - Start Command : `node server.js`
   - **Runtime Docker** : rien à saisir, le `Dockerfile` fourni fait tout.
4. Health check path : `/sante`.
5. Déployez. L'adresse ressemble à
   `https://formation-continue-pompiers.onrender.com`.

Aucune dépendance à installer : le serveur n'utilise que Node.

### Si le déploiement a déjà échoué

Le message **« failed to read dockerfile: open Dockerfile: no such file or
directory »** signifie que Render est en mode Docker sans trouver de
`Dockerfile`. Deux façons de s'en sortir :

- **le plus simple** : ce paquet contient désormais un `Dockerfile` —
  poussez-le à la racine du dépôt et relancez le déploiement (*Manual Deploy
  → Deploy latest commit*) ;
- ou basculez le service en Node : **Settings → Runtime → Node**, avec les
  commandes de build et de démarrage ci-dessus.

---

## Utilisation

- **Équipage** : ouvrez l'adresse sur les trois téléphones →
  carte « 👥 Équipage » → un joueur crée l'équipe, les autres saisissent
  le code de 4 lettres et choisissent leur rôle.
- **Progression** : écran **Statistiques** → bloc « Sauvegarde en ligne » →
  choisissez un code personnel (4 à 12 caractères) → **↑ Envoyer**.
  Sur un autre téléphone, même code → **↓ Récupérer**.

## Ce qui est stocké — et ce qui survit

Le serveur cherche un dossier inscriptible dans cet ordre : `DATA_DIR`, puis
un dossier local, puis `/tmp`. Si aucun n'accepte l'écriture, il bascule tout
seul **en mémoire** : le service reste utilisable, il ne plante jamais.

**Sur le plan gratuit, rien n'est durable.** Render réserve les disques
persistants aux plans payants, et un service gratuit s'éteint après 15 min
sans visite (réveil : environ une minute) : à chaque redémarrage, les équipes
en cours et les progressions envoyées repartent à zéro. Pour un entraînement
en caserne c'est sans conséquence. Pour conserver l'historique sur des mois :
plan payant + disque `/var/data` (bloc à décommenter dans `render.yaml`), ou
la **version Netlify**, dont les Blobs conservent la progression gratuitement.

Le contenu, sous `DATA_DIR` :

- `equipes/CODE.json` — une session d'équipe (prénoms, rôles, mission,
  scores), effacée d'elle-même au bout de 6 h ;
- `joueurs/CODE.json` — l'instantané de progression d'un joueur
  (scores par intervention, XP, historique, notes de fiches bilan).

Aucune donnée personnelle au-delà du prénom saisi par le joueur.

## Mettre à jour l'application

Remplacez `public/index.html` (et les icônes si elles changent), poussez,
puis redéployez. Vérifiez que le numéro de cache du service worker
(`public/sw.js`, constante `CACHE`) a bien changé : sinon les téléphones
déjà installés garderont l'ancienne version.

## Différence avec la version Netlify

Les deux sont fournies et se valent côté joueur. Render tient l'application
et les deux API dans un seul processus Node avec un disque ; Netlify sert les
fichiers et exécute deux fonctions (`/api/equipe`, `/api/progression`)
adossées à Netlify Blobs. Sur l'offre gratuite de Render, le service s'endort
après inactivité : le premier chargement peut demander une trentaine de
secondes.
